namespace CocoBom.Models
{
    public class Produto
    {
        public int Id {get; set;}
        public int Codigo {get; set;}
        public string Titulo {get; set;}
        public string Sabor {get; set;}
        public string Ingredientes {get; set;}
        public double Preco {get; set;}
        public string Imagem {get;set;}
    }
}