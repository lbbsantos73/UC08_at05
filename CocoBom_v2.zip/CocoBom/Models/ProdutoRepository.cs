using MySqlConnector;
using System.Collections.Generic;

namespace CocoBom.Models
{
    public class ProdutoRepository
    {
        private const string _strConexao = "Database=cocobom;Data Source=127.0.0.1; User Id=root;";

        public void Excluir(int numId)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();

            string sql = "DELETE FROM produto WHERE id = @ID";
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@Id", numId);
            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void Incluir(Produto p)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();

            string sql = "INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem)";
            sql = sql + " VALUES (@Codigo, @Titulo, @Sabor, @Ingredientes, @Preco, @Imagem)";

            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@Codigo", p.Codigo);
            comando.Parameters.AddWithValue("@Titulo", p.Titulo);
            comando.Parameters.AddWithValue("@Sabor", p.Sabor);
            comando.Parameters.AddWithValue("@Ingredientes", p.Ingredientes);
            comando.Parameters.AddWithValue("@Preco", p.Preco);
            comando.Parameters.AddWithValue("@Imagem", p.Imagem);
            comando.ExecuteNonQuery();

            conexao.Close();
        }

        public void Atualizar(Produto p)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();

            string sql = "UPDATE produto set codigo = @Codigo, titulo = @Titulo, sabor = @Sabor,";
            sql = sql + " ingredientes = @Ingredientes, preco = @Preco, imagem = @Imagem WHERE id = @Id";

            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@Id", p.Id);
            comando.Parameters.AddWithValue("@Codigo", p.Codigo);
            comando.Parameters.AddWithValue("@Titulo", p.Titulo);
            comando.Parameters.AddWithValue("@Sabor", p.Sabor);
            comando.Parameters.AddWithValue("@Ingredientes", p.Ingredientes);
            comando.Parameters.AddWithValue("@Preco", p.Preco);
            comando.Parameters.AddWithValue("@Imagem", p.Imagem);
            comando.ExecuteNonQuery();

            conexao.Close();
        }

        public List<Produto> Query()
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();
            string sql = "SELECT * FROM produto";
            MySqlCommand comandoQuery = new MySqlCommand(sql, conexao);
            MySqlDataReader reader = comandoQuery.ExecuteReader();
            List<Produto> lista = new List<Produto>();
            while (reader.Read())
            {
                Produto prod = new Produto();
                prod.Id = reader.GetInt32("Id");

                if(!reader.IsDBNull(reader.GetOrdinal("Codigo")))
                    prod.Codigo = reader.GetInt32("Codigo");
                if(!reader.IsDBNull(reader.GetOrdinal("Titulo")))
                    prod.Titulo = reader.GetString("Titulo");
                if(!reader.IsDBNull(reader.GetOrdinal("Sabor")))
                    prod.Sabor = reader.GetString("Sabor");
                if(!reader.IsDBNull(reader.GetOrdinal("Ingredientes")))
                    prod.Ingredientes = reader.GetString("Ingredientes");
                if(!reader.IsDBNull(reader.GetOrdinal("Imagem")))
                    prod.Imagem = reader.GetString("Imagem");
                prod.Preco = reader.GetDouble("Preco");
                lista.Add(prod);
            }
            conexao.Close();
            return lista;
        }

         public Produto QueryProduto(int ID)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();
            string sql = "SELECT * FROM produto WHERE id = @ID";
            MySqlCommand comandoQuery = new MySqlCommand(sql, conexao);
            comandoQuery.Parameters.AddWithValue("@ID", ID);
            MySqlDataReader reader = comandoQuery.ExecuteReader();
            Produto prod = null;
            if (reader.Read())
            {
                prod = new Produto();
                prod.Id = reader.GetInt32("Id");
                if(!reader.IsDBNull(reader.GetOrdinal("Codigo")))
                    prod.Codigo = reader.GetInt32("Codigo");
                if(!reader.IsDBNull(reader.GetOrdinal("Titulo")))
                    prod.Titulo = reader.GetString("Titulo");
                if(!reader.IsDBNull(reader.GetOrdinal("Sabor")))
                    prod.Sabor = reader.GetString("Sabor");
                if(!reader.IsDBNull(reader.GetOrdinal("Ingredientes")))
                    prod.Ingredientes = reader.GetString("Ingredientes");
                if(!reader.IsDBNull(reader.GetOrdinal("Imagem")))
                    prod.Imagem = reader.GetString("Imagem");
                prod.Preco = reader.GetDouble("Preco");
            }
            conexao.Close();
            return prod;
        }


    }
}