namespace CocoBom.Models
{
    public class Comentario
    {
        public int Id {get;set;}
        public string Nome {get;set;}
        public string Email {get;set;}
        public string Mensagem {get; set;}
        public int Resposta {get; set;}
    }
}