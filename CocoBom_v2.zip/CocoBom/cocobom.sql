-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01-Dez-2020 às 17:59
-- Versão do servidor: 10.4.14-MariaDB
-- versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cocobom`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario`
--

CREATE TABLE `comentario` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mensagem` varchar(255) NOT NULL,
  `resposta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `comentario`
--

INSERT INTO `comentario` (`id`, `nome`, `email`, `mensagem`, `resposta`) VALUES
(1, 'Fulano de Tal', 'fulano@mail.com', 'Esta é uma mensagem de teste para ver se funciona.', 0),
(2, 'José da Silva', 'jsilva@mail.com.br', 'Esta é uma mensagem de teste para ver se o incluir no banco de dados está funcionando.', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `id` int(11) NOT NULL,
  `codigo` int(11) NOT NULL,
  `titulo` varchar(20) DEFAULT 'Sabor não definido',
  `sabor` varchar(50) DEFAULT NULL,
  `ingredientes` varchar(100) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `imagem` varchar(50) DEFAULT '~/imagens/no-photo-240-0.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `codigo`, `titulo`, `sabor`, `ingredientes`, `preco`, `imagem`) VALUES
(1, 12501, 'Amendoim', 'Bala recheada sabor amendoim', 'Ingredientes: água, açúcar, leite de coco, leite condensado e amendoim.', '10.00', '~/imagens/amendoim.jpeg'),
(2, 12502, 'Beijinho', 'Bala recheada sabor beijinho', 'Ingredientes: água, açúcar, leite de coco, leite condensado e coco ralado.', '10.00', '~/imagens/beijinho.jpeg'),
(3, 12503, 'Cereja', 'Bala recheada sabor cereja', 'Ingredientes: água, açúcar, leite de coco, leite condensado, fruta e corante.', '10.00', '~/imagens/cereja.jpeg'),
(4, 12504, 'Coco Queimado', 'Bala recheada sabor coco queimado', 'Ingredientes: água, açúcar, leite de coco, leite condensado e coco ralado torrado.', '10.00', '~/imagens/coco-queimado.jpeg'),
(5, 12505, 'Coco Tradicional', 'Bala de coco sem recheio', 'Ingredientes: água, açúcar, leite de coco.', '10.00', '~/imagens/coco-tradicional.jpeg'),
(6, 12506, 'Gengibre', 'Bala recheada sabor gengibre', 'Ingredientes: água, açúcar, leite de coco, leite condensado e gengibre desidratado.', '10.00', '~/imagens/gengibre.jpeg'),
(7, 12507, 'Leite Ninho', 'Bala recheada sabor leite ninho', 'Ingredientes: água, açúcar, leite de coco, leite condensado e leite em pó integral.', '10.00', '~/imagens/leite-ninho.jpeg'),
(8, 12508, 'Maracujá', 'Bala recheada sabor maracujá', 'Ingredientes: água, açúcar, leite de coco, leite condensado e maracujá desidratado.', '10.00', '~/imagens/maracuja.jpeg'),
(9, 12509, 'Morango', 'Bala recheada sabor morango', 'Ingredientes: água, açúcar, leite de coco, leite condensado e nesquick.', '10.00', '~/imagens/morango.jpeg'),
(10, 12510, 'Nozes', 'Bala recheada sabor nozes', 'Ingredientes: água, açúcar, leite de coco, leite condensado e nozes.', '10.00', '~/imagens/nozes.jpeg'),
(11, 12511, 'Nutella', 'Bala recheada sabor nutella', 'Ingredientes: água, açúcar, leite de coco, leite condensado, creme de leite e nutella.', '10.00', '~/imagens/nutella.jpeg'),
(12, 12512, 'Prestígio', 'Bala recheada sabor prestígio', 'Ingredientes: água, açúcar, leite de coco, leite condensado, chocolate em pó e coco ralado.', '10.00', '~/imagens/prestigio.jpeg'),
(13, 12513, 'Café', 'Bala recheada sabor café', 'Ingredientes: Água, açúcar, leite de coco, leite condensado e café solúvel.', '10.00', '~/imagens/cafe.jpeg'),
(15, 12515, 'Uva', 'Bala recheada sabor uva', 'Ingredientes: Água, açúcar, leite de coco, leite condensado e essência de uva.', '10.00', '~/imagens/uva.jpeg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `login` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `tipo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `login`, `senha`, `tipo`) VALUES
(1, 'Luciano Baginski', 'admin', 'senhasecreta', 0),
(2, 'André Ricardo', 'potter', 'potter123', 1),
(4, 'João Roberto', 'robertoj', '12345', 0),
(5, 'Pedro da Silva', 'pedro92', 'senhadopedro', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
